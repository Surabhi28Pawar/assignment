#include<stdio.h>
#include<file_1.h>


void  file_1()
{
	printf("\n file 1 execution successful\n");
}

