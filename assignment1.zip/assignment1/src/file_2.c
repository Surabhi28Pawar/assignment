#include<stdio.h>
#include<file_2.h>

void file_2()
{
	printf("\n file 2 execution successful\n");
}
