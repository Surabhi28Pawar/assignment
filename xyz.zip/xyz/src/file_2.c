#include<stdio.h>
#include"file_2.h"

void file_2()
{
	printf("FILE 2 wORKING PROPERLY\n");
}
