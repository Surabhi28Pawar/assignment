#include<stdio.h>
#include"file_1.h"
void  file_1()
{
	printf("FILE 1 WORKING PROPERLY\n");
}
