#include<stdio.h>
#include"file_1.h"
#include"file_2.h"
void main()
{
	file_1();
	file_2();
	printf("END FILE ....... work done\n");
}

